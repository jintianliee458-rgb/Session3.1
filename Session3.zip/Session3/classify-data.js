'use strict';

const fs = require('node:fs/promises');
const path = require('node:path');

async function main() {
  const inputPath = path.join(__dirname, 'customers.json');
  const outputPath = path.join(__dirname, 'medicationbyvolume.json');
  const customers = JSON.parse(await fs.readFile(inputPath, 'utf8'));

  if (!Array.isArray(customers)) {
    throw new Error('customers.json must contain a JSON array.');
  }

  const medications = customers.map((record, index) => {
    if (record === null || typeof record !== 'object' || Array.isArray(record)) {
      throw new Error(`Record ${index + 1} must be an object.`);
    }

    for (const field of ['medication', 'city', 'county']) {
      if (typeof record[field] !== 'string' || record[field].trim() === '') {
        throw new Error(`Record ${index + 1}: ${field} must be a non-empty string.`);
      }
    }

    if (!Number.isSafeInteger(record.volume) || record.volume < 0) {
      throw new Error(`Record ${index + 1}: volume must be a non-negative safe integer.`);
    }

    // Allowlist fields so identifiers and any future source fields cannot leak.
    // Preserve source geography labels; correcting them needs verified reference data.
    return {
      medication: record.medication,
      volume: record.volume,
      county: record.county,
      city: record.city,
    };
  });

  // Validate every record before writing. The source file is never modified.
  await fs.writeFile(outputPath, JSON.stringify(medications, null, 2) + '\n', {
    mode: 0o600,
  });
  console.log(`Created medicationbyvolume.json with ${medications.length} records.`);
}

main().catch((error) => {
  // Avoid logging source values, which may contain sensitive personal data.
  if (error instanceof SyntaxError) {
    console.error('Data transformation failed: customers.json contains invalid JSON.');
  } else {
    console.error(`Data transformation failed: ${error.message}`);
  }
  process.exitCode = 1;
});
