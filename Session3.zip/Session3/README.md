# Workshop 5: Sensitive Data Classification

### Implementation and execution

| File | Purpose |
| --- | --- |
| `customers.json` | Original operational dataset; unchanged. The PDF sometimes calls this `customer.json`. |
| `classify-data.js` | JavaScript transformation using only Node.js built-in modules. |
| `medicationbyvolume.json` | Generated analysis datastore containing only medication, volume, county and city. |

Run with Node.js 18 or later; no package installation is needed:

```bash
node classify-data.js
```

The script resolves both JSON paths relative to its own directory. Rerunning it regenerates `medicationbyvolume.json`. It validates the input array, required non-empty text fields and non-negative integer volumes before writing. An explicit field allowlist excludes `name`, `chino`, `ethnicity` and any unexpected extra fields. It creates the output with owner-only read/write permissions on systems supporting Unix file modes. These file permissions are only a local safeguard; production access policies require separate enforcement.

The supplied file contains **55,027 records**, rather than exactly 50,000 customers. A record is a medication entry, not necessarily a distinct customer. The output keeps all 55,027 entries and the original total volume of **579,255**. Units are unspecified in the source, so the implementation does not assume tablets, packs or prescriptions.


### Task 1

#### 1. What is the appropriate classification for the datastore?

Classify `customers.json` as **Confidential — highly sensitive personal data**, with the highest applicable internal protection tier. Names and CHI numbers identify people, while linked medication and ethnicity reveal sensitive information. Health and ethnic-origin data are special category personal data under UK GDPR. “Confidential” is PiC's proposed organisational label, rather than a statutory classification name.
The principal risks are identity misuse, disclosure of treatment, discrimination, unauthorised employee browsing and linkage with other datasets. Apply encryption in transit and at rest, controlled keys, access logging and restrictions on downloads and onward sharing.

#### 2. What sort of access should be granted to PiC employees?

Use role-based access control, least privilege and a documented business need. Deny access by default and limit both records and fields:

| Role | Necessary access |
| --- | --- |
| Authorised dispensing/fulfilment staff | Relevant patient and order details needed for assigned work; writes limited to their responsibilities. |
| Delivery staff | Assigned delivery details only; no routine access to ethnicity, CHI numbers or full medication histories. |
| Inventory and forecasting analysts | Read-only access to the minimised analysis datastore; no customer identifiers. |
| HR staff | Separate employee compliance datastore; customer ethnicity is not employee HR evidence. |
| Compliance/security reviewers | Approved, scoped and logged access for a defined review. |
| Other employees | No access unless a specific need is approved. |

Use individual accounts, MFA, periodic access reviews and prompt revocation when roles change. Restrict administration and use audited emergency access where necessary. Do not give an entire department unrestricted access merely because some of its staff need certain records.

#### 3. How long should PiC store a customer's information?

Use a documented, purpose-specific retention schedule. There is no single duration established by this worksheet. Keep identifiable information only while needed for the relevant service or a justified obligation, then delete or effectively anonymise it.
For PiC, I recommend separating active account details, transient delivery information, clinical/dispensing records and financial records. Remove transient delivery details after confirmed completion and any justified resolution period. Keep any required clinical or financial records in separately restricted stores under an approved schedule appropriate to their record type and jurisdiction. Account closure should trigger a review, rather than automatic deletion of every record or indefinite retention. Apply expiry to exports, replicas and backups, with documented, time-limited holds when necessary. The worksheet does not provide enough information to claim a universal statutory number of years.


### Task 2

#### 1. Generate `medicationbyvolume.json`

Implemented in `classify-data.js`; the generated datastore is included. Each output object contains exactly:

```json
{
  "medication": "Metoprolol Tartrate",
  "volume": 10,
  "county": "Abertillery",
  "city": "Gwent"
}
```

Both city and county are retained as the general location needed by the scenario. Names, CHI numbers and ethnicity are removed. Records are neither deduplicated nor aggregated, so every original volume remains available for summing by medicine and location. This is data minimisation, not a claim of anonymity.
The source example appears to interchange city and county values. The script preserves supplied labels and values; geographic validation against an authoritative reference is required before interpreting regional results. It also preserves row order, which can allow direct matching to the original file if both files are accessible. Access separation is therefore essential. For wider sharing, prefer aggregated totals, assess small groups and linkage risks, and suppress or generalise unsafe results. Removing direct identifiers alone does not establish anonymity.

#### 2. How should classification labels support retention and access control?

| Datastore | Proposed label | Access policy | Retention policy |
| --- | --- | --- | --- |
| `customers.json` / operational records | Confidential — identifiable health and ethnicity data | Authorised operational roles, scoped to task; approved compliance access | Separate schedules for account, delivery, clinical and finance purposes; delete unneeded copies. |
| `medicationbyvolume.json` | Confidential — minimised health-related analysis data | Approved inventory/analysis roles, normally read-only; controlled export | Defined analysis window, reviewed and enforced; no automatic indefinite retention. |
| Future disclosure-reviewed aggregate reports | Internal, or a lower tier only after a documented risk assessment | Approved business audience or explicitly authorised recipients | A justified reporting schedule; periodic usefulness and disclosure review. |

Removing identifiers reduces exposure but does not justify public access or automatically lowering the analysis file to “Public”. Associate each label with a data owner, approved purpose, permitted roles and actions, retention trigger and duration, and disposal method. Enforce these through database permissions, controlled views, logging and scheduled expiry; a filename or label alone does not enforce policy.

#### 3. Which access design strategy is recommended?

**Choose (c): restrict the operational database to the operations team, and grant analysis access only to those who need it.** Within the operations team, still apply the role and field restrictions described above.

#### 4. How can retention improve using the new data objects?

Separate short-lived identifiable delivery processing from the history needed for inventory analysis. Retain the minimised analysis data only for a documented forecasting purpose. As an illustrative business proposal, a rolling **24-month** window could support comparison across two annual cycles, but PiC must validate that need and shorten the window if possible; this is not a legal minimum.
The supplied objects have no order date, completion date or timestamp, so this static extract cannot implement age-based expiry, seasonality analysis or delivery-speed measurement. In production, use verified source event dates and store retention metadata separately from the required four-field export, for example per dated batch. For this undated file, assign a documented batch review/expiry date without inventing historical order dates. Automate expiry, log disposal and review exceptions. Longer-term summaries should use medicine/location totals, with small-group disclosure checks, rather than retaining unnecessary individual entries. Customer records also cannot substitute for the separate employee data needed for HR analysis.

#### 5. Which retention policy is recommended?

**Choose (b), as the closest option:** retain analysis data for the time needed for the analysis within the storage budget, and delete delivery data after order completion is confirmed.

#### 6. Which statements about identifiable sensitive data are true?

**(d), “All of the above”, is the likely intended answer**. 
